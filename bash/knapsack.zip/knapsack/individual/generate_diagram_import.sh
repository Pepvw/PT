#!/bin/bash

echo "digraph D {"
for f in $( find ../ -name '*.java')
do
    s=${f##*/} # removes path
    s=${s%.*} #removes .java
    export s # Exports so s is usable in perl
    cat $f |
    perl -0ne 'while (/import\s+\S+\b([A-Z]\S+?);/gs) {print "$ENV{s} -> $1 [arrowhead=dot]\n";}'
done

echo "}"
