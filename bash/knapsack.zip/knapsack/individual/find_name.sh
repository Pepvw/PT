#!/bin/bash

# r: Search recursively.
# H: Print filename.
# n: Print line number.
# include: Searches all .js files.
# $1: Argument passed.
# ../: Search parent directory (knapsack directory in this case)
grep -rHn --include="*.java" "$1" ../
