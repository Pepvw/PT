#!/bin/bash

echo "digraph D {"
for f in $( find .. -name '*.java')
do
    cat $f | ./remove_comments.sh |
    perl -0ne 'while (/class.(\S+).extends.(\S+)/sg) {print "$1 -> $2\n";}'

done
echo "}"
