#!/bin/bash

# !/bin/bash
# find: Find command.
# i: Changes the original.
# s: Substitude command.
# $1: First argument passed.
# $2: Second argument passd.
# {} Uses file found by find command.
find ../ -name "*.java" -exec sed -i "s/$1/$2/" {} +
