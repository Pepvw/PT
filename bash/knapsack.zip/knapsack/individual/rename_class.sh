#!/bin/bash

# !/bin/bash
# find: Find command.
# i: Changes the original.
# s: Substitude command.
# $1: First argument passed.
# $2: Second argument passd.
# {} Uses file found by find command.

# Changes all the instances in files
find ../ -name "*.java" -exec sed -i "s/$1/$2/" {} +

# Renames the filename to the new name.
for f in $( find ../ -name $1.java)
do
mv "$1.java" "$2.java"
done

