#!/bin/bash
echo "digraph D {"
    for f in $( find .. -name '*.java')
    do
        cat $f | ./remove_comments.sh | ./get_classes.sh | sed 's/$/ [shape=box]/g'
    done

    echo 'subgraph package_solvers { label = "package solvers"'
    for f in $( find .. -name '*.java')
    do
        cat $f | ./remove_comments.sh |
        perl -0ne 'while (/class.(\S+).extends.(\S+)/sg) {print "$1 -> $2\n";}'

    done
    echo '}'

    for f in $( find ../ -name '*.java')
    do
        s=${f##*/} # removes path
        s=${s%.*} #removes .java
        export s # Exports so s is usable in perl
        cat $f |
        perl -0ne 'while (/import\s+\S+\b([A-Z]\S+?);/gs) {print "$ENV{s} -> $1 [arrowhead=dot]\n";}'
    done

    echo 'subgraph cluster_X { label = "package problem"'
    for f in $( find .. -name '*.java')
    do
    s=${f##*/}

    if  grep -q "package problem;" $f ;
    then
        echo "  ${s%.*} [shape=box]"
    fi
    done
    echo "}"

    echo 'subgraph cluster_Y { label = "package solvers"'
    for f in $( find .. -name '*.java')
    do
    s=${f##*/}

    if  grep -q "package solvers;" $f ;
    then
        echo "  ${s%.*} [shape=box]"
    fi
    done
    echo "}"

echo "}"
