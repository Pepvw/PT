#!/bin/bash

echo "digraph D {"

echo 'subgraph cluster_X { label = "package problem"'
for f in $( find .. -name '*.java')
do
s=${f##*/}

if  grep -q "package problem;" $f ;
then
    echo "  ${s%.*} [shape=box]"
fi
done
echo "}"

echo 'subgraph cluster_Y { label = "package solvers"'
for f in $( find .. -name '*.java')
do
s=${f##*/}

if  grep -q "package solvers;" $f ;
then
    echo "  ${s%.*} [shape=box]"
fi
done
echo "}"


echo "}"
